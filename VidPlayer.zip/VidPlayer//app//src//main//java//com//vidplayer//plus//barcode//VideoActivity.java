package com.vidplayer.plus.barcode;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.SeekBar;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.github.rubensousa.previewseekbar.*;
import arabware.credits.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class VideoActivity extends  AppCompatActivity  { 
	
	
	private String path = "";
	private HashMap<String, Object> data = new HashMap<>();
	private String title = "";
	private double videoHeight = 0;
	private double videoWidth = 0;
	
	private LinearLayout linearmain;
	private LinearLayout secandarymain;
	private LinearLayout linear3;
	private LinearLayout linear1;
	private LinearLayout upword;
	private LinearLayout back;
	private LinearLayout linear17;
	private LinearLayout forwordddd;
	private LinearLayout linear12;
	private TextView love;
	private TextView cuple;
	private LinearLayout playbausbox;
	private LinearLayout linear11;
	private LinearLayout linear13;
	private LinearLayout linear20;
	private ImageView imageview5;
	private LinearLayout linear21;
	private TextView textview1;
	private LinearLayout linear7;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private ImageView backword;
	private ImageView playpuse;
	private ImageView forword;
	private TextView compdur;
	private SeekBar seekbar1;
	private TextView totaldur;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.video);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linearmain = (LinearLayout) findViewById(R.id.linearmain);
		secandarymain = (LinearLayout) findViewById(R.id.secandarymain);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		upword = (LinearLayout) findViewById(R.id.upword);
		back = (LinearLayout) findViewById(R.id.back);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		forwordddd = (LinearLayout) findViewById(R.id.forwordddd);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		love = (TextView) findViewById(R.id.love);
		cuple = (TextView) findViewById(R.id.cuple);
		playbausbox = (LinearLayout) findViewById(R.id.playbausbox);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear20 = (LinearLayout) findViewById(R.id.linear20);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		linear21 = (LinearLayout) findViewById(R.id.linear21);
		textview1 = (TextView) findViewById(R.id.textview1);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		backword = (ImageView) findViewById(R.id.backword);
		playpuse = (ImageView) findViewById(R.id.playpuse);
		forword = (ImageView) findViewById(R.id.forword);
		compdur = (TextView) findViewById(R.id.compdur);
		seekbar1 = (SeekBar) findViewById(R.id.seekbar1);
		totaldur = (TextView) findViewById(R.id.totaldur);
	}
	
	private void initializeLogic() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
		getWindow().setStatusBarColor(Color.TRANSPARENT);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		getWindow().getDecorView().setSystemUiVisibility( View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
		data = new Gson().fromJson(getIntent().getStringExtra("data"), new TypeToken<HashMap<String, Object>>(){}.getType());
		videoHeight = Double.parseDouble(data.get("videoHeight").toString());
		videoWidth = Double.parseDouble(data.get("videoWidth").toString());
		if (videoWidth > videoHeight) {
			setRequestedOrientation(Build.VERSION.SDK_INT < 9 ?
			
			android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE :
			                  android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
		}
		else {
			
		}
		path = data.get("videoPath").toString();
		_videoview(path);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _videoview (final String _path) {
		final VideoView vd = new VideoView(VideoActivity.this);
		vd.setLayoutParams(new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.MATCH_PARENT));
		linear1.addView(vd);
		vd.setVideoURI(Uri.parse(_path));
				vd.setMediaController(new MediaController(this));
				vd.requestFocus();
		vd.start();
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}